// JavaScript Document
( function()
{
var Date = moment();
document.getElementById('currDatePlus7d').innerHTML = Date.subtract('days', 2);
document.getElementById('currDatePlus7d').innerHTML = Date.format('D MMMM, YYYY');

})();
